import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../controllers/auth_controller.dart';
import '../../controllers/current_room_controller.dart';
import '../../core/router/app_routes.dart';
import '../shared/loading_widgets.dart';

/// Primeira tela que abre quando o app inicia.
///
/// Ela não tem nenhum botão: só existe pra dar tempo do [AuthController]
/// checar se já existe uma sessão salva (professor logado pelo Firebase
/// Auth, ou aluno salvo localmente pelo SharedPreferences) antes de decidir
/// pra onde mandar o usuário — tela de login, dashboard do professor ou
/// base do aluno.
class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  @override
  void initState() {
    super.initState();
    // Espera o primeiro frame ser desenhado antes de mexer no router,
    // porque context.go() não pode ser chamado durante o build.
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkSession());
  }

  Future<void> _checkSession() async {
    final auth = context.read<AuthController>();
    await auth.tryAutoLogin();

    if (!mounted) return;

    if (auth.isProfessor) {
      // Sincroniza a sala restaurada (lida do SharedPreferences dentro de
      // tryAutoLogin) com o CurrentRoomController, que é o que o Dashboard
      // realmente consulta pra saber qual sala carregar. Sem isso, o
      // Dashboard não sabia qual era a última sala selecionada logo após
      // reabrir o app.
      final restoredRoom = auth.currentRoom;
      if (restoredRoom != null) {
        context.read<CurrentRoomController>().selectRoom(restoredRoom);
      }
      context.go(AppRoutes.professorDashboard);
    } else if (auth.currentStudent != null) {
      context.go(AppRoutes.studentHome);
    } else {
      context.go(AppRoutes.login);
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: AppLoadingSplash(),
    );
  }
}
